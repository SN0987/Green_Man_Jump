#pragma once
#include <iostream>
#include <random>




namespace Random {
    
    int getRandom(int max);

    int getRandom(int min, int max);

}